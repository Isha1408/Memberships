﻿    function jwVideo(video) {
        jwplayer("video").setup(
            {
                file: video
            });
    }
